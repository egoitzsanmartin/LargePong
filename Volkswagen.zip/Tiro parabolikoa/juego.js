/* Burak Kanber */
var width = 1400;
var height = 700;
var canvas = ctx = false;
var frameRate = 1/40; // Seconds
var frameDelay = frameRate * 1000; // ms
var loopTimer = false;



var ball = {
    position: {x: width/2, y: 0},
    velocity: {x: 10, y: 0},
    mass: 0.1, //kg
    radius: 15, // 1px = 1cm
    restitution: -0.7
    };

var Cd = 0.47;  // Dimensionless
var rho = 1.22; // Dentsitatea
var A = Math.PI * ball.radius * ball.radius / (10000); // Azalera
var ag = 9.81;  // Grabitatea
var mouse = {x: 0, y: 0, isDown: false};
var puntuak = 0;

//saguaren posizioa hartzen du eta mouse.x eta mouse.y aldagaietan gordetzen du
function getMousePosition(e) {
    mouse.x = e.pageX - canvas.offsetLeft;
    mouse.y = e.pageY - canvas.offsetTop;
}
var mouseDown = function(e) {
    if (e.which == 1) {
        getMousePosition(e);
        mouse.isDown = true;
        //ball.position.x = mouse.x;
        //ball.position.y = mouse.y;
    }
}
var mouseUp = function(e) {
    if (e.which == 1) {
        mouse.isDown = false;
        ball.velocity.y = (ball.position.y - mouse.y) /10;
        ball.velocity.x = (ball.position.x - mouse.x) / 10;
        puntuak++;
    }
}

var hasi = function() {
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext('2d');

    canvas.onmousemove = getMousePosition;
    canvas.onmousedown = mouseDown;
    canvas.onmouseup = mouseUp;

    ctx.fillStyle = 'black';
    ctx.strokeStyle = '#000000';
    loopTimer = setInterval(loop, frameDelay);

//Bolaren hasierako egoerak.

    ball.position.x = 150;
    ball.position.y = 400;
    ball.velocity.x=0;
    ball.velocity.y = 0;

}



var loop = function() {
    if ( ! mouse.isDown) {
        // Fisikak definitzeko
            // Indarren formula: Fd = -1/2 * Cd * A * rho * v * v
        var Fx = -0.5 * Cd * A * rho * ball.velocity.x * ball.velocity.x * ball.velocity.x / Math.abs(ball.velocity.x);
        var Fy = -0.5 * Cd * A * rho * ball.velocity.y * ball.velocity.y * ball.velocity.y / Math.abs(ball.velocity.y);

        Fx = (isNaN(Fx) ? 0 : Fx); //Fx-en balioa definituta egon ezin denean, Fx 0 balioa hartzen du.
        Fy = (isNaN(Fy) ? 0 : Fy);

            // bolaren azelerazioa
        var ax = Fx / ball.mass;
        var ay = ag + (Fy / ball.mass);

            // Bolari abiadura ematen dio
        ball.velocity.x += ax*frameRate;
        ball.velocity.y += ay*frameRate;

            // Bolari posizioa ematen dio
        ball.position.x += ball.velocity.x*frameRate*100;
        ball.position.y += ball.velocity.y*frameRate*100;
    }
    // Bolaren kolisioak paretekin
    if (ball.position.y > 500 - ball.radius) {
        ball.velocity.y *= ball.restitution;
        ball.position.y = 500 - ball.radius;
    }
    if (ball.position.x > width - ball.radius) {
        ball.velocity.x *= ball.restitution;
        ball.position.x = width - ball.radius;
    }
    if (ball.position.x < ball.radius) {
        ball.velocity.x *= ball.restitution;
        ball.position.x = ball.radius;
    }
    if (ball.position.y < 0 + ball.radius){
      ball.velocity.y *= ball.restitution;
      ball.position.y = 0 + ball.radius;
    }
   

//Bola marraztu

    ctx.clearRect(0,0,width,height);

    ctx.save();
//bolaren posizioak definitzeko
    ctx.translate(ball.position.x, ball.position.y);
    ctx.beginPath();
    //bolaren dimentsioak definitzeko
    ctx.arc(0, 0, ball.radius, 0, Math.PI*2, true);
    ctx.fill();
    ctx.closePath();

    ctx.restore();


    // Tiroaren marratxoa marrazteko
    if (mouse.isDown) {
        ctx.beginPath();
        ctx.moveTo(ball.position.x, ball.position.y);
        ctx.lineTo(mouse.x, mouse.y);
        ctx.stroke();
        ctx.closePath();
    }

    //Puntuazioa

      ctx.font = "30px impact";
      ctx.fillStyle = '#555555';
      ctx.fillText(`${puntuak}`,950,55);
}
    hasi();
