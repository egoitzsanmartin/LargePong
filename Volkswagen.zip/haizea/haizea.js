/* Burak Kanber */
var width = 1000;
var height = 1000;
var canvas = ctx = false;
var frameRate = 1/40; // Seconds
var frameDelay = frameRate * 1000; // ms
var loopTimer = false;




var ball = {
    position: {x: width/2, y: 0},
    velocity: {x: 10, y: 0},
    mass: 0.1, //kg
    radius: 15, // 1px = 1cm
    restitution: -0.7
    };

var Cd = 0.47;  // Dimensionless
var rho = 1.22; // Dentsitatea
var A = Math.PI * ball.radius * ball.radius / (10000); // Azalera
var ag = 9.81;  // Grabitatea
var mouse = {x: 0, y: 0, isDown: false};

    protected Vector3 enteredVelocity;

    protected bool windIsActive = false;
    protected GameObject ball;

    protected abstract void activateWind();


function iniciar(){
	var modal = document.getElementById("modal");
	modal.style.display = "none";
	frame();
}

 private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "ball"){
     
            ball = other.gameObject;

            var ballRb = other.GetComponent<Rigidbody>();
            enteredVelocity = ballRb.velocity;
            EventSystem.enteredWind();


            windIsActive = true;
            activateWind();

        }

    }

        // bolaren azelerazioa
        var ax = Fx / ball.mass;
        var ay = ag + (Fy / ball.mass);
            // Bolari abiadura ematen dio
        entered.velocity.x += ax*frameRate;
        ballRb.velocity.y += ay*frameRate;

            // Bolari posizioa ematen dio
        ball.position.x += ball.velocity.x*frameRate*100;
        ball.position.y += ball.velocity.y*frameRate*100;



//Bola marraztu

    ctx.clearRect(0,0,width,height);

    ctx.save();

    ctx.translate(ball.position.x, ball.position.y);
    ctx.beginPath();
    ctx.arc(0, 0, ball.radius, 0, Math.PI*2, true);
    ctx.fill();
    ctx.closePath();

    ctx.restore();